## kubernetes API client libraries

### Supported
   * [Go](https://github.com/GoogleCloudPlatform/kubernetes/tree/master/pkg/client)

### User Contributed
*Note: Libraries provided by outside parties are supported by their authors, not the core Kubernetes team*

   * [Java](https://github.com/nirmal070125/KubernetesAPIJavaClient)
   * [Ruby](https://github.com/Ch00k/kuber)

