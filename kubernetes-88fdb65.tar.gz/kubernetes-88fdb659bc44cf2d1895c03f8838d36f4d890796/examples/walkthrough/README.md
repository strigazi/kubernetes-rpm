# Kubernetes Walkthrough

## Pods
The first atom of Kubernetes is a _pod_.  A pod is a collection of containers that are symbiotically group.

See [pods](https://github.com/GoogleCloudPlatform/kubernetes/blob/master/docs/pods.md) for more details.

### Intro

Trivially, a single container might be a pod.  For example, you can express a simple web server as a pod:

```yaml
apiVersion: v1beta1
id: www
desiredState:
  manifest:
    version: v1beta1
    id: www
    containers:
      - name: nginx
        image: dockerfile/nginx
```

A pod definition is a declaration of a _desired state_.  Desired state is a really important part of Kubernetes.  Many things present a desired state to the system, and it is Kubernetes' responsibility to make sure that the current state matches the desired state.  For example, when you create a Pod, you declare that you want the containers in it to be running.  If the containers happen to not be running (program failure, ...), Kubernetes will continue to (re)create them for you until you delete the Pod.

See the [design document](https://github.com/GoogleCloudPlatform/kubernetes/blob/master/DESIGN.md) for more details.

### Volumes

Now that's great for a static webserver, but what about persistent storage?  We know that the container file system only lives as long as the container does, we need more persistent storage.  To do this, you also declare a ```volume``` as part of your pod, and mount it into a container:

```yaml
apiVersion: v1beta1
id: storage
desiredState:
  manifest:
    version: v1beta1
    id: storage
    containers:
      - name: redis
        image: dockerfile/redis
        volumeMounts:
            # name must match the volume name below
          - name: redis-persistent-storage
            # mount path within the container
            mountPath: /data/redis
    volumes:
      - name: redis-persistent-storage
        source:
          emptyDir: {}
```

Ok, so what did we do?  We added a volume to our pod:
```yaml
...
    volumes:
      - name: redis-persistent-storage
        source:
          emptyDir: {}
...
```

And we added a reference to that volume to our container:
```yaml
...
        volumeMounts:
            # name must match the volume name below
          - name: redis-persistent-storage
            # mount path within the container
            mountPath: /data/redis
...
```

In Kubernetes, ```emptyDir``` Volumes live for the lifespan of the Pod, which is longer than the lifespan of any one container, so if the container fails and is restarted, our persistent storage will live on.

If you want to mount a directory that already exists in the file system (e.g. ```/var/logs```) you can use the ```hostDir``` directive.

See [volumes](https://github.com/GoogleCloudPlatform/kubernetes/blob/master/docs/volumes.md) for more details.

### Multiple Containers

_Note:
The examples below are syntactically correct, but some of the images (e.g. kubernetes/git-monitor) don't exist yet.  We're working on turning these into working examples._


However, often you want to have two different containers that work together.  An example of this would be a web server, and a helper job that polls a git repository for new updates:

```yaml
apiVersion: v1beta1
id: www
desiredState:
  manifest:
    version: v1beta1
    id: www
    containers:
      - name: nginx
        image: dockerfile/nginx
        volumeMounts:
          - name: www-data
            mountPath: /srv/www
            readOnly
    containers:
      - name: git-monitor
        image: kubernetes/git-monitor
        envVar:
          - name: GIT_REPO
            value: http://github.com/some/repo.git
        volumeMounts:
          - name: www-data
            mountPath: /data
    volumes:
      - name: www-data
        source:
          emptyDir
```

Note that we have also added a volume here.  In this case, the volume is mounted into both containers.  It is marked ```readOnly``` in the web server's case, since it doesn't need to write to the directory.

Finally, we have also introduced an environment variable to the ```git-monitor``` container, which allows us to parameterize that container with the particular git repository that we want to track.


### What's next?
For a complete application see the [guestbook example](https://github.com/GoogleCloudPlatform/kubernetes/tree/master/examples/guestbook)
